const express = require("express");
const cors = require("cors");
const path = require("path");
const sqlite3 = require("sqlite3").verbose();

const app = express();
const PORT = process.env.PORT || 5000;
const db = new sqlite3.Database(path.join(__dirname, "gym.db"));

app.use(cors());
app.use(express.json());

db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS members (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      phone TEXT NOT NULL,
      email TEXT NOT NULL,
      plan TEXT NOT NULL,
      monthlyFee REAL NOT NULL CHECK (monthlyFee >= 0),
      joinDate TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Active',
      createdAt TEXT DEFAULT CURRENT_TIMESTAMP
    )
  `);
});

function validateMember(body) {
  const { name, phone, email, plan, monthlyFee, joinDate, status } = body;
  if (![name, phone, email, plan, joinDate].every(v => typeof v === "string" && v.trim())) {
    return "Name, phone, email, membership plan, and join date are required.";
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) return "Enter a valid email address.";
  if (monthlyFee === "" || monthlyFee === null || monthlyFee === undefined || !Number.isFinite(Number(monthlyFee)) || Number(monthlyFee) < 0) {
    return "Monthly fee must be a valid non-negative number.";
  }
  if (status !== undefined && !["Active", "Inactive"].includes(status)) return "Status must be Active or Inactive.";
  if (!/^\d{4}-\d{2}-\d{2}$/.test(joinDate)) return "Join date must be a valid date.";
  return null;
}

app.get("/api/health", (_req, res) => res.json({ status: "ok" }));

app.get("/api/members", (_req, res) => {
  db.all("SELECT * FROM members ORDER BY id DESC", [], (err, rows) => {
    if (err) return res.status(500).json({ error: "Could not load members." });
    res.json(rows);
  });
});

app.post("/api/members", (req, res) => {
  const error = validateMember(req.body);
  if (error) return res.status(400).json({ error });
  const { name, phone, email, plan, monthlyFee, joinDate, status = "Active" } = req.body;

  db.run(
    `INSERT INTO members (name, phone, email, plan, monthlyFee, joinDate, status)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [name.trim(), phone.trim(), email.trim(), plan, Number(monthlyFee), joinDate, status],
    function (err) {
      if (err) return res.status(500).json({ error: "Could not add member." });
      db.get("SELECT * FROM members WHERE id = ?", [this.lastID], (_e, row) => res.status(201).json(row));
    }
  );
});

app.put("/api/members/:id", (req, res) => {
  const error = validateMember(req.body);
  if (error) return res.status(400).json({ error });
  const { name, phone, email, plan, monthlyFee, joinDate, status = "Active" } = req.body;

  db.run(
    `UPDATE members SET name=?, phone=?, email=?, plan=?, monthlyFee=?, joinDate=?, status=?
     WHERE id=?`,
    [name.trim(), phone.trim(), email.trim(), plan, Number(monthlyFee), joinDate, status, req.params.id],
    function (err) {
      if (err) return res.status(500).json({ error: "Could not update member." });
      if (!this.changes) return res.status(404).json({ error: "Member not found." });
      db.get("SELECT * FROM members WHERE id = ?", [req.params.id], (_e, row) => res.json(row));
    }
  );
});

app.delete("/api/members/:id", (req, res) => {
  db.run("DELETE FROM members WHERE id = ?", [req.params.id], function (err) {
    if (err) return res.status(500).json({ error: "Could not delete member." });
    if (!this.changes) return res.status(404).json({ error: "Member not found." });
    res.json({ message: "Member deleted successfully." });
  });
});

app.listen(PORT, () => console.log(`FitZone API running at http://localhost:${PORT}`));