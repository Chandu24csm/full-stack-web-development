import { useEffect, useMemo, useState } from "react";

const today = new Date().toISOString().slice(0, 10);
const emptyForm = { name: "", phone: "", email: "", plan: "Monthly", monthlyFee: "1500", joinDate: today, status: "Active" };

async function api(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Request failed.");
  return data;
}

export default function App() {
  const [members, setMembers] = useState([]);
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState(null);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("All");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  async function loadMembers() {
    setLoading(true);
    try {
      setMembers(await api("/api/members"));
      setError("");
    } catch (e) {
      setError(`${e.message} Make sure the backend is running.`);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadMembers(); }, []);

  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase();
    return members.filter(m => {
      const matchesSearch = [m.name, m.phone, m.email, m.plan].some(v => String(v).toLowerCase().includes(term));
      const matchesStatus = filter === "All" || m.status === filter;
      return matchesSearch && matchesStatus;
    });
  }, [members, search, filter]);

  const activeCount = members.filter(m => m.status === "Active").length;
  const revenue = members.filter(m => m.status === "Active").reduce((sum, m) => sum + Number(m.monthlyFee), 0);
  const plans = new Set(members.filter(m => m.status === "Active").map(m => m.plan)).size;

  function change(e) {
    setForm(current => ({ ...current, [e.target.name]: e.target.value }));
  }

  function resetForm() {
    setForm(emptyForm);
    setEditingId(null);
    setError("");
  }

  async function submit(e) {
    e.preventDefault();
    setSaving(true);
    setError("");
    setNotice("");
    try {
      const payload = { ...form, monthlyFee: Number(form.monthlyFee) };
      if (editingId) {
        await api(`/api/members/${editingId}`, { method: "PUT", body: JSON.stringify(payload) });
        setNotice("Member details updated successfully.");
      } else {
        await api("/api/members", { method: "POST", body: JSON.stringify(payload) });
        setNotice("New gym member added successfully.");
      }
      resetForm();
      await loadMembers();
    } catch (e) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  }

  function edit(member) {
    setEditingId(member.id);
    setForm({
      name: member.name, phone: member.phone, email: member.email, plan: member.plan,
      monthlyFee: String(member.monthlyFee), joinDate: member.joinDate, status: member.status
    });
    setError("");
    setNotice("");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function remove(member) {
    if (!window.confirm(`Remove ${member.name} from the gym records?`)) return;
    setError("");
    setNotice("");
    try {
      await api(`/api/members/${member.id}`, { method: "DELETE" });
      setMembers(current => current.filter(m => m.id !== member.id));
      if (editingId === member.id) resetForm();
      setNotice("Member record deleted.");
    } catch (e) {
      setError(e.message);
    }
  }

  return (
    <div className="app">
      <aside className="sidebar">
        <div className="logo"><div className="logo-mark">F</div><span>FIT<span className="lime-text">ZONE</span><small>GYM MANAGEMENT</small></span></div>
        <div className="side-label">MAIN MENU</div>
        <div className="side-link selected"><span>▦</span> Dashboard</div>
        <div className="side-link"><span>♙</span> Members</div>
        <div className="side-link"><span>◷</span> Membership plans</div>
        <div className="side-link"><span>▥</span> Payments</div>
        <div className="side-note"><div className="pulse"></div><div><strong>KEEP MOVING</strong><p>Small steps. Strong results.</p></div></div>
        <div className="sidebar-footer"><div className="admin-avatar">GM</div><div><strong>Gym Manager</strong><small>Administrator</small></div><span className="dots">•••</span></div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div><div className="breadcrumb">WORKSPACE <span>/</span> OVERVIEW</div><h1>Gym dashboard <span className="title-dot">.</span></h1><p className="subtitle">Manage your members. Build a stronger community.</p></div>
          <div className="top-actions"><span className="live"><i></i> LIVE OVERVIEW</span><div className="date-box">▦ <span>{new Date().toLocaleDateString(undefined, { day: "2-digit", month: "short", year: "numeric" })}</span></div></div>
        </header>

        <section className="hero">
          <div className="hero-copy"><div className="hero-tag"><span>✦</span> YOUR FITNESS BUSINESS</div><h2>STRONGER<br />STARTS <span>HERE.</span></h2><p>Every member is a new opportunity to make progress. Let's make today count.</p><button onClick={() => { document.getElementById("member-form")?.scrollIntoView({ behavior: "smooth", block: "start" }); document.getElementById("member-name")?.focus(); }}>＋ Add a member <span>↗</span></button></div>
          <div className="hero-visual" aria-hidden="true"><div className="hero-ring ring-one"></div><div className="hero-ring ring-two"></div><div className="hero-number">01<span>/ GO</span></div><div className="hero-barbell"><div className="plate plate-left"></div><div className="bar"></div><div className="grip"></div><div className="plate plate-right"></div></div><div className="hero-caption">DISCIPLINE OVER MOTIVATION <span>✳</span></div></div>
          <div className="hero-index">FZ / 2026</div>
        </section>

        {notice && <div className="alert good">{notice}<button onClick={() => setNotice("")}>×</button></div>}
        {error && <div className="alert bad">{error}<button onClick={() => setError("")}>×</button></div>}

        <section className="stats">
          <article className="stat"><div className="stat-head">TOTAL MEMBERS <span className="stat-icon">♙</span></div><div className="stat-value">{members.length.toString().padStart(2, "0")}<span> members</span></div><div className="stat-foot"><span className="lime-line"></span> All registered members</div></article>
          <article className="stat"><div className="stat-head">ACTIVE MEMBERS <span className="stat-icon">↗</span></div><div className="stat-value">{activeCount.toString().padStart(2, "0")}<span> active</span></div><div className="stat-foot"><span className="lime-line"></span> Currently active status</div></article>
          <article className="stat"><div className="stat-head">MONTHLY REVENUE <span className="stat-icon">₹</span></div><div className="stat-value money">₹{revenue.toLocaleString("en-IN")}<span>/mo</span></div><div className="stat-foot"><span className="lime-line"></span> Active plans' monthly fees</div></article>
          <article className="stat"><div className="stat-head">ACTIVE PLAN TYPES <span className="stat-icon">▤</span></div><div className="stat-value">{plans.toString().padStart(2, "0")}<span> types</span></div><div className="stat-foot"><span className="lime-line"></span> Plans currently in use</div></article>
        </section>

        <section className="workspace">
          <article className="panel form-panel" id="member-form">
            <div className="panel-head"><div><div className="section-kicker">MEMBER DATABASE</div><h3>{editingId ? "Edit member" : "Register a member"}</h3></div><span className="plus-mark">＋</span></div>
            <form onSubmit={submit}>
              <label htmlFor="member-name">FULL NAME</label><input id="member-name" name="name" value={form.name} onChange={change} placeholder="e.g. Rahul Kumar" maxLength="100" required />
              <label htmlFor="member-phone">PHONE NUMBER</label><input id="member-phone" name="phone" value={form.phone} onChange={change} placeholder="e.g. 9876543210" maxLength="25" required />
              <label htmlFor="member-email">EMAIL ADDRESS</label><input id="member-email" type="email" name="email" value={form.email} onChange={change} placeholder="member@example.com" required />
              <div className="two-fields"><div><label htmlFor="member-plan">MEMBERSHIP PLAN</label><select id="member-plan" name="plan" value={form.plan} onChange={change}><option>Monthly</option><option>Quarterly</option><option>Half-Yearly</option><option>Yearly</option><option>Personal Training</option></select></div><div><label htmlFor="member-fee">MONTHLY FEE (₹)</label><input id="member-fee" type="number" name="monthlyFee" value={form.monthlyFee} onChange={change} min="0" step="1" required /></div></div>
              <div className="two-fields"><div><label htmlFor="member-date">JOIN DATE</label><input id="member-date" type="date" name="joinDate" value={form.joinDate} onChange={change} required /></div><div><label htmlFor="member-status">STATUS</label><select id="member-status" name="status" value={form.status} onChange={change}><option>Active</option><option>Inactive</option></select></div></div>
              <div className="form-buttons"><button className="submit-btn" disabled={saving}>{saving ? "Saving..." : editingId ? "Save changes ↗" : "Register member ↗"}</button>{editingId && <button type="button" className="cancel-btn" onClick={resetForm}>Cancel</button>}</div>
            </form>
            <div className="form-tip"><span>✳</span> Good records make a great gym.</div>
          </article>

          <article className="panel members-panel">
            <div className="members-top"><div><div className="section-kicker">YOUR COMMUNITY</div><h3>Gym members <span className="member-count">{filtered.length}</span></h3></div><button className="refresh" onClick={loadMembers} title="Refresh members">↻</button></div>
            <div className="list-tools"><div className="search"><span>⌕</span><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search name, phone, email..." aria-label="Search members" /></div><select value={filter} onChange={e => setFilter(e.target.value)} aria-label="Filter by status"><option>All</option><option>Active</option><option>Inactive</option></select></div>
            {loading ? <div className="empty">Loading members...</div> : filtered.length === 0 ? <div className="empty"><div className="empty-symbol">↗</div><strong>{search || filter !== "All" ? "No members found" : "Your member list is ready"}</strong><p>{search || filter !== "All" ? "Try changing your search or status filter." : "Register your first member using the form."}</p></div> : (
              <div className="table-wrap"><table><thead><tr><th>MEMBER</th><th>PLAN</th><th>MONTHLY FEE</th><th>STATUS</th><th>ACTIONS</th></tr></thead><tbody>
                {filtered.map(m => <tr key={m.id}><td><div className="member-cell"><div className="member-avatar">{m.name.trim().split(/\s+/).slice(0,2).map(s => s[0]).join("").toUpperCase()}</div><div><strong>{m.name}</strong><small>{m.phone} · {m.email}</small></div></div></td><td><span className="plan-chip">{m.plan}</span></td><td className="fee">₹{Number(m.monthlyFee).toLocaleString("en-IN")}</td><td><span className={`status ${m.status.toLowerCase()}`}><i></i>{m.status}</span></td><td><div className="actions"><button onClick={() => edit(m)} title="Edit member" aria-label={`Edit ${m.name}`}>✎</button><button onClick={() => remove(m)} className="remove" title="Delete member" aria-label={`Delete ${m.name}`}>×</button></div></td></tr>)}
              </tbody></table></div>
            )}
            <div className="table-footer"><span>SHOWING <b>{filtered.length}</b> OF <b>{members.length}</b> MEMBERS</span><span className="db-status"><i></i> DATABASE CONNECTED</span></div>
          </article>
        </section>
        <footer className="footer"><span>FITZONE <b>GYM MANAGEMENT SYSTEM</b></span><span>BUILT FOR PROGRESS <i>✳</i></span></footer>
      </main>
    </div>
  );
}